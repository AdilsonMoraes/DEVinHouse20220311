﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HerancaConsole
{
    public class Pessoa
    {
        #region Atributos
        public string Nome { get; set; }
        public int Idade { get; set; }
        #endregion


        #region Metodos
        public void MensagemPessoa()
        {
            Console.WriteLine($"Nome: {Nome}");
            Console.WriteLine($"Idade: {Idade}");
        }
        #endregion
    }
}
