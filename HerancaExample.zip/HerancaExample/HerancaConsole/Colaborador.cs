﻿using System;

namespace HerancaConsole
{
    public class Colaborador : Pessoa
    {
        #region Atributos
        public double Salario { get; set; }
        #endregion

        #region Construtor
        public Colaborador()
        {

        }

        public Colaborador(string nome, int idade, double salario)
        {
            this.Nome = nome;
            this.Idade = idade;
            this.Salario = salario;

            MensagemPessoa();
            MensagemColaborador();
        }
        #endregion

        #region Metodos
        public void MensagemColaborador()
        {
            Console.WriteLine($"Salário: {Salario}");

        }
        #endregion
    }
}
