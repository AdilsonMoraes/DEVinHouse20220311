﻿using System;

namespace HerancaConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var colaborador = new Colaborador("Adilson", 34, 2000);


            var teste = new Colaborador();
            teste.Nome = "Adilson";
            teste.Idade = 10;
            teste.Salario = 50;
            teste.MensagemPessoa();
            teste.MensagemColaborador();
        }
    }
}
